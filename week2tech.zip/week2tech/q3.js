var input, a_len, i;
var names = ["Amar", "Raja", "Rani"];
var places = ["Chennai", "Delhi", "Banglore"];
a_len = names.length;
input = '<table border="1" cellspacing="0" cellpadding="5">';
input += "<tr><th>Name</th><th>Place</th></tr>";
for (i = 0; i < a_len; i++) {
    input += "<tr><td>" + names[i] + "</td><td>" + places[i] + "</td></tr>";
}
input += "</table>";
document.getElementById("c1").innerHTML = input;
